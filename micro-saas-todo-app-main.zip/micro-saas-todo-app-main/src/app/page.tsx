export default function Home() {
  return <main>Landing Page</main>
}
