export { GET, POST } from '@/services/auth'
