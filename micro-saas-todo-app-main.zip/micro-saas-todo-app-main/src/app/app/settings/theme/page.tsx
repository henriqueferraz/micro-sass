import { ThemeForm } from './_componens/form'

export default function Page() {
  return <ThemeForm />
}
